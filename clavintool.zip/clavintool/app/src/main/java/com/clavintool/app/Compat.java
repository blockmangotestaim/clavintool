package com.clavintool.app;

/**
 * Lua 5.1 / LuaJIT compatibility layer. LuaJ implements Lua 5.2, but most obfuscators (Luraph & co.)
 * and many scripts expect loadstring, unpack, getfenv/setfenv, math.pow, the 'bit' library, ...
 */
final class Compat {
    private Compat() {}

    /** getfenv/setfenv implemented natively (LuaJ's debug library is not loaded, it would slow every script down). */
    static void install(final org.luaj.vm2.Globals g) {
        g.set("getfenv", new org.luaj.vm2.lib.VarArgFunction() {
            @Override public org.luaj.vm2.Varargs invoke(org.luaj.vm2.Varargs a) {
                org.luaj.vm2.LuaValue f = a.arg1();
                if (f instanceof org.luaj.vm2.LuaClosure) {
                    org.luaj.vm2.LuaClosure c = (org.luaj.vm2.LuaClosure) f;
                    for (int i = 0; i < c.p.upvalues.length; i++) {
                        if (c.p.upvalues[i].name != null && "_ENV".equals(c.p.upvalues[i].name.tojstring()) && c.upValues[i] != null)
                            return c.upValues[i].getValue();
                    }
                }
                return g;
            }
        });
        g.set("setfenv", new org.luaj.vm2.lib.VarArgFunction() {
            @Override public org.luaj.vm2.Varargs invoke(org.luaj.vm2.Varargs a) {
                org.luaj.vm2.LuaValue f = a.arg1();
                if (f instanceof org.luaj.vm2.LuaClosure) {
                    org.luaj.vm2.LuaClosure c = (org.luaj.vm2.LuaClosure) f;
                    for (int i = 0; i < c.p.upvalues.length; i++) {
                        if (c.p.upvalues[i].name != null && "_ENV".equals(c.p.upvalues[i].name.tojstring()) && c.upValues[i] != null) {
                            c.upValues[i].setValue(a.arg(2));
                            break;
                        }
                    }
                }
                return f;
            }
        });
    }

    static final String LUA =
        "loadstring = loadstring or load\n" +
        "unpack = unpack or table.unpack\n" +
        "table.getn = table.getn or function(t) return #t end\n" +
        "table.maxn = table.maxn or function(t) local m = 0 for k in pairs(t) do if type(k) == 'number' and k > m then m = k end end return m end\n" +
        "math.pow = math.pow or function(a, b) return a ^ b end\n" +
        "math.mod = math.mod or math.fmod\n" +
        "math.log10 = math.log10 or function(x) return math.log(x) / math.log(10) end\n" +
        "string.gfind = string.gfind or string.gmatch\n" +
        "if not bit and bit32 then\n" +
        "  local function tobit(x) x = x % 4294967296 if x >= 2147483648 then x = x - 4294967296 end return x end\n" +
        "  bit = {\n" +
        "    tobit = tobit,\n" +
        "    band = function(...) return tobit(bit32.band(...)) end,\n" +
        "    bor = function(...) return tobit(bit32.bor(...)) end,\n" +
        "    bxor = function(...) return tobit(bit32.bxor(...)) end,\n" +
        "    bnot = function(x) return tobit(bit32.bnot(x)) end,\n" +
        "    lshift = function(x, n) return tobit(bit32.lshift(x, n)) end,\n" +
        "    rshift = function(x, n) return tobit(bit32.rshift(x, n)) end,\n" +
        "    arshift = function(x, n) return tobit(bit32.arshift(x, n)) end,\n" +
        "    rol = function(x, n) return tobit(bit32.lrotate(x, n)) end,\n" +
        "    ror = function(x, n) return tobit(bit32.rrotate(x, n)) end,\n" +
        "    tohex = function(x, n) n = n or 8 return string.format('%0' .. n .. 'x', bit32.band(x, 0xFFFFFFFF)):sub(-n) end,\n" +
        "  }\n" +
        "end\n";
}
