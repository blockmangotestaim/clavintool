package com.clavintool.app;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

/** A Lua table crossing the JNI boundary: array part (1..n) plus alternating key/value pairs for the rest. */
public final class LuaTbl {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    public final Object[] arr;
    public final Object[] kv;

    /** Called from native code. String keys arrive as byte[]; they are normalised to String here. */
    public LuaTbl(Object[] arr, Object[] kv) {
        this.arr = arr == null ? new Object[0] : arr;
        this.kv = kv == null ? new Object[0] : kv;
        for (int i = 0; i < this.kv.length; i += 2) {
            if (this.kv[i] instanceof byte[]) this.kv[i] = new String((byte[]) this.kv[i], UTF8);
        }
    }

    public static LuaTbl list(List<?> items) {
        return new LuaTbl(items.toArray(new Object[0]), null);
    }

    /** map("address", 5L, "value", 1L ...) */
    public static LuaTbl map(Object... pairs) {
        return new LuaTbl(null, pairs);
    }

    public int length() { return arr.length; }

    public Object get(long index) {
        return index >= 1 && index <= arr.length ? arr[(int) index - 1] : null;
    }

    public Object get(String key) {
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (key.equals(kv[i])) return kv[i + 1];
        }
        return null;
    }

    /** All keys in iteration order: 1..n first, then the hash keys. */
    public List<Object> keys() {
        ArrayList<Object> k = new ArrayList<>();
        for (int i = 1; i <= arr.length; i++) k.add(Long.valueOf(i));
        for (int i = 0; i + 1 < kv.length; i += 2) k.add(kv[i]);
        return k;
    }

    public Object getAny(Object key) {
        if (key instanceof Long) {
            Object v = get((Long) key);
            if (v != null) return v;
        }
        for (int i = 0; i + 1 < kv.length; i += 2) {
            if (key.equals(kv[i])) return kv[i + 1];
        }
        return null;
    }
}
